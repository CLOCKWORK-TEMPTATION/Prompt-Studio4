
export const playgroundSuggestions: string[] = [
    'Generate a blog post outline on remote work benefits',
    'Draft ad copy for a new eco-friendly coffee brand',
    'Create a Python function docstring for a factorial calculator',
    'Design a 3-day vegetarian meal plan',
    'Explain quantum computing to a 5-year-old',
    'Write a professional email to request a deadline extension',
    'Generate a SQL query to find all users from California',
    'Create a SWOT analysis for a new tech startup',
    'Generate creative story ideas from a simple concept',
];
