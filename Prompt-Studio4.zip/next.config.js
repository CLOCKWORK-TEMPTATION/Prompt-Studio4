/** @type {import('next').NextConfig} */
const nextConfig = {
  // Add any other config options here
}

export default nextConfig;
