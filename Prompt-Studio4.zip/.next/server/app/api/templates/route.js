var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/templates/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__8806a2d0._.js")
R.c("server/chunks/_next-internal_server_app_api_templates_route_actions_a59f4640.js")
R.m(56793)
module.exports=R.m(56793).exports
