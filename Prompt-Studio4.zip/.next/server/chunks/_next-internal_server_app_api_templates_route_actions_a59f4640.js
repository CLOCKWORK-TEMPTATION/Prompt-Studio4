module.exports=[76328,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_templates_route_actions_a59f4640.js.map