module.exports=[55500,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_runs_page_actions_1c92a680.js.map