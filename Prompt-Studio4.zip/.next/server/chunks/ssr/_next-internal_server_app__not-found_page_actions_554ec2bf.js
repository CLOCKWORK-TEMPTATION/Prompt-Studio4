module.exports=[57665,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app__not-found_page_actions_554ec2bf.js.map