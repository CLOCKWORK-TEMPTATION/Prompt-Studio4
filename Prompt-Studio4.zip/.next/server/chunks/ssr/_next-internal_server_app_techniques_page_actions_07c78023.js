module.exports=[76140,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_techniques_page_actions_07c78023.js.map