import "dotenv/config";
import { db } from "./storage";
import { templates, techniques } from "@shared/schema";

const SEED_TEMPLATES = [
  {
    name: "محلل الكود (Bug Finder)",
    description: "تحليل كود برمجي لاكتشاف الأخطاء الأمنية والمنطقية.",
    category: "Development",
    tags: ["Code", "Security", "Review"],
    sections: {
      system: "أنت خبير أمن سيبراني ومطور برمجيات متمرس (Senior Developer).",
      developer: "ركز على الثغرات الأمنية (OWASP Top 10) وكفاءة الأداء.",
      user: "راجع الكود التالي واكتشف الأخطاء المحتملة:\n\n```{{language}}\n{{code}}\n```\n\nقدم تقريراً بالأخطاء مع تصحيح مقترح.",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "language", value: "typescript" },
      { id: "v2", name: "code", value: "function login(user) { eval(user.input); }" }
    ]
  },
  {
    name: "كاتب محتوى فيرال (Viral)",
    description: "كتابة تغريدات أو منشورات قصيرة جداً وجذابة.",
    category: "Marketing",
    tags: ["Social", "Twitter", "Viral"],
    sections: {
      system: "أنت خبير تسويق رقمي متخصص في كتابة الـ Copywriting الجذاب.",
      developer: "استخدم الـ Hooks القوية في البداية. اجعل الجمل قصيرة. استخدم الرموز التعبيرية.",
      user: "اكتب سلسلة تغريدات (Thread) عن موضوع: {{topic}}.\nالهدف: {{goal}}.",
      context: "الجمهور: مهتمون بالتقنية وريادة الأعمال."
    },
    defaultVariables: [
      { id: "v1", name: "topic", value: "الذكاء الاصطناعي في 2025" },
      { id: "v2", name: "goal", value: "زيادة المتابعين" }
    ]
  },
  {
    name: "مترجم تقني دقيق",
    description: "ترجمة النصوص التقنية مع الحفاظ على المصطلحات.",
    category: "Translation",
    tags: ["Translation", "Tech", "Arabic"],
    sections: {
      system: "أنت مترجم تقني محترف من الإنجليزية إلى العربية.",
      developer: "لا تترجم المصطلحات البرمجية الشائعة (مثل API, React, Hook) بل اتركها كما هي أو اكتبها وعربها بين قوسين.",
      user: "ترجم النص التالي للعربية بدقة:\n\n{{text}}",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "text", value: "The API endpoint returns a JSON response with a 200 OK status." }
    ]
  },
  {
    name: "منشئ بيانات JSON وهمية",
    description: "توليد بيانات عشوائية للاختبار (Mock Data).",
    category: "Data",
    tags: ["JSON", "Mock", "Testing"],
    sections: {
      system: "أنت مولد بيانات (Data Generator).",
      developer: "مخرجاتك حصراً JSON Array صالح (Valid JSON). لا تضف أي شرح.",
      user: "أنتج قائمة JSON تحتوي على {{count}} عنصر.\nكل عنصر يمثل {{entity}} ويحتوي على الحقول: {{fields}}.",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "count", value: "5" },
      { id: "v2", name: "entity", value: "مستخدم (User)" },
      { id: "v3", name: "fields", value: "id, name, email, role" }
    ]
  },
  {
    name: "ملخص الاجتماعات",
    description: "تحويل تفريغ نصي لاجتماع إلى محضر منظم.",
    category: "Productivity",
    tags: ["Summary", "Business", "Meeting"],
    sections: {
      system: "أنت سكرتير تنفيذي دقيق.",
      developer: "استخدم تنسيق Markdown. قسم الملخص إلى: القرارات، المهام (Action Items)، والنقاشات الرئيسية.",
      user: "لخص محضر الاجتماع التالي:\n\n{{transcript}}",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "transcript", value: "أحمد: يجب أن نغير التصميم. سارة: موافقة، سأقوم بذلك غداً." }
    ]
  },
  {
    name: "مولد استعلامات SQL",
    description: "تحويل الطلب اللغوي الطبيعي إلى كود SQL.",
    category: "Development",
    tags: ["SQL", "Database", "Query"],
    sections: {
      system: "أنت خبير قواعد بيانات SQL.",
      developer: "افترض أن قاعدة البيانات هي PostgreSQL. اكتب الكود فقط.",
      user: "اكتب استعلام SQL لـ: {{request}}.\n\nمخطط الجدول (Schema) هو:\n{{schema}}",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "request", value: "جلب الموظفين الذين انضموا بعد 2023 ورواتبهم فوق 5000" },
      { id: "v2", name: "schema", value: "Employees(id, name, join_date, salary)" }
    ]
  },
  {
    name: "كاتب المقالات التقنية",
    description: "كتابة مقالات طويلة متخصصة في المواضيع التقنية.",
    category: "Content",
    tags: ["Blog", "Technical", "SEO"],
    sections: {
      system: "أنت كاتب محتوى تقني متخصص بخبرة 10 سنوات.",
      developer: "استخدم عناوين واضحة، أمثلة عملية، وشرح مفاهيم معقدة بطريقة بسيطة.",
      user: "اكتب مقالة عن {{topic}} موجهة لـ {{audience}}. الطول: {{word_count}} كلمة. النبرة: {{tone}}.",
      context: "اجعل المقالة غنية بالمعلومات والأمثلة الحقيقية."
    },
    defaultVariables: [
      { id: "v1", name: "topic", value: "مقدمة إلى Machine Learning" },
      { id: "v2", name: "audience", value: "مبتدئين" },
      { id: "v3", name: "word_count", value: "2000" },
      { id: "v4", name: "tone", value: "تعليمي وودود" }
    ]
  },
  {
    name: "مولد أفكار الأعمال",
    description: "توليد أفكار نشاط تجاري مبتكرة وقابلة للتنفيذ.",
    category: "Business",
    tags: ["Startup", "Ideas", "Innovation"],
    sections: {
      system: "أنت مستشار ريادة أعمال متخصص في تطوير الأفكار المبتكرة.",
      developer: "قدم أفكار عملية وقابلة للتنفيذ مع نموذج العمل الأساسي.",
      user: "أنشئ {{count}} أفكار مشاريع في المجال: {{industry}}. للسوق {{market}}.",
      context: "اشمل: الفكرة الأساسية، المشكلة التي تحلها، نموذج الربح المتوقع."
    },
    defaultVariables: [
      { id: "v1", name: "count", value: "5" },
      { id: "v2", name: "industry", value: "التقنية الحضراء" },
      { id: "v3", name: "market", value: "السعودية" }
    ]
  },
  {
    name: "محسّن الإيميلات",
    description: "تحسين وتحرير رسائل البريد الإلكتروني.",
    category: "Communication",
    tags: ["Email", "Professional", "Copy"],
    sections: {
      system: "أنت خبير في الاتصالات التجارية والكتابة الاحترافية.",
      developer: "حسّن من حيث الوضوح والتأثير والاحترافية. احتفظ بالرسالة الأساسية.",
      user: "حسّن هذا الإيميل:\n\n{{email}}\n\nالهدف: {{goal}}",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "email", value: "مرحبا، أحتاج مساعدتك في المشروع" },
      { id: "v2", name: "goal", value: "طلب رسمي للمساعدة" }
    ]
  },
  {
    name: "مولد الحملات التسويقية",
    description: "إنشاء خطة حملة تسويقية متكاملة متعددة القنوات.",
    category: "Marketing",
    tags: ["Campaign", "Strategy", "Marketing"],
    sections: {
      system: "أنت مدير حملات تسويقية بخبرة عشر سنوات.",
      developer: "قدم استراتيجية متكاملة مع KPIs وجدول زمني واضح.",
      user: "صمّم حملة تسويقية لـ: {{product}}. الميزانية: {{budget}}. المدة: {{duration}}.",
      context: "الجمهور المستهدف: {{audience}}. الأهداف: {{goals}}"
    },
    defaultVariables: [
      { id: "v1", name: "product", value: "تطبيق جوال للتعليم" },
      { id: "v2", name: "budget", value: "100,000 ريال" },
      { id: "v3", name: "duration", value: "3 أشهر" },
      { id: "v4", name: "audience", value: "الطلاب الجامعيين 18-25" },
      { id: "v5", name: "goals", value: "زيادة التحميلات بـ 50%" }
    ]
  },
  {
    name: "مولد محتوى السوشيال ميديا",
    description: "إنشاء محتوى متنوع لمنصات التواصل الاجتماعي المختلفة.",
    category: "Content",
    tags: ["Social", "Instagram", "TikTok"],
    sections: {
      system: "أنت خبير في إنشاء محتوى فيروسي للسوشيال ميديا.",
      developer: "اجعل المحتوى جذاباً وقابلاً للمشاركة. استخدم Hashtags مناسبة.",
      user: "أنشئ {{count}} منشورات عن {{topic}} للمنصة {{platform}}.",
      context: "النبرة: {{tone}}. الجمهور: {{audience}}"
    },
    defaultVariables: [
      { id: "v1", name: "count", value: "5" },
      { id: "v2", name: "topic", value: "نصائح الإنتاجية اليومية" },
      { id: "v3", name: "platform", value: "Instagram" },
      { id: "v4", name: "tone", value: "خفيف وودود" },
      { id: "v5", name: "audience", value: "رجال الأعمال الشباب" }
    ]
  },
  {
    name: "محلل الأفكار النقدي",
    description: "تحليل الفكرة من زوايا نقدية متعددة.",
    category: "Analysis",
    tags: ["Critical", "Analysis", "Thinking"],
    sections: {
      system: "أنت مفكر ناقد متخصص في تحليل الأفكار والمشاريع.",
      developer: "قدم تحليلاً موازناً مع نقاط القوة والضعف والفرص والتهديدات.",
      user: "حلل الفكرة التالية: {{idea}}\nقدم تقييماً نقدياً شاملاً.",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "idea", value: "تطبيق توصيل الطعام بطائرات بدون طيار" }
    ]
  },
  {
    name: "مولد الأسئلة التدريبية",
    description: "إنشاء أسئلة تدريبية وامتحانات فعالة.",
    category: "Education",
    tags: ["Quiz", "Exam", "Training"],
    sections: {
      system: "أنت متخصص في تطوير المناهج والتقييمات التعليمية.",
      developer: "أنشئ أسئلة متنوعة من حيث مستوى الصعوبة والنوع (اختيار من متعدد، مقالي، صح وخطأ).",
      user: "أنشئ {{count}} أسئلة عن {{subject}} لـ مستوى {{level}}.",
      context: "الصعوبة: {{difficulty}}"
    },
    defaultVariables: [
      { id: "v1", name: "count", value: "10" },
      { id: "v2", name: "subject", value: "البرمجة بلغة Python" },
      { id: "v3", name: "level", value: "متوسط" },
      { id: "v4", name: "difficulty", value: "متدرج من السهل للصعب" }
    ]
  },
  {
    name: "كاتب القصص والسيناريوهات",
    description: "كتابة قصص وسيناريوهات خيالية أو واقعية.",
    category: "Creative",
    tags: ["Story", "Creative", "Fiction"],
    sections: {
      system: "أنت كاتب قصص موهوب مع خبرة في السيناريو والإبداع الأدبي.",
      developer: "استخدم وصفاً حياً، شخصيات معقدة، وأحداث درامية.",
      user: "اكتب {{type}} عن {{premise}}. الطول: {{length}}. النمط: {{style}}.",
      context: "الإعداد الزمني: {{time_period}}. الموقع: {{location}}"
    },
    defaultVariables: [
      { id: "v1", name: "type", value: "قصة قصيرة" },
      { id: "v2", name: "premise", value: "مهندس يكتشف ثغرة في قاعدة بيانات الحكومة" },
      { id: "v3", name: "length", value: "1500 كلمة" },
      { id: "v4", name: "style", value: "إثارة وتشويق" },
      { id: "v5", name: "time_period", value: "مستقبل قريب" },
      { id: "v6", name: "location", value: "السعودية - الرياض" }
    ]
  },
  {
    name: "مولد خطط المشاريع",
    description: "إنشاء خطط مشاريع تفصيلية مع جدول زمني.",
    category: "Management",
    tags: ["Project", "Planning", "Timeline"],
    sections: {
      system: "أنت مدير مشاريع محترف برزمجيات إدارة متقدمة.",
      developer: "قدم خطة مفصلة مع مراحل، مسؤوليات، ومؤشرات نجاح.",
      user: "أنشئ خطة مشروع لـ: {{project_name}}. المدة: {{duration}}. الميزانية: {{budget}}.",
      context: "الفريق: {{team_size}} شخص. التحديات المتوقعة: {{challenges}}"
    },
    defaultVariables: [
      { id: "v1", name: "project_name", value: "تطوير منصة التعليم الإلكترونية" },
      { id: "v2", name: "duration", value: "6 أشهر" },
      { id: "v3", name: "budget", value: "500,000 ريال" },
      { id: "v4", name: "team_size", value: "15" },
      { id: "v5", name: "challenges", value: "التكامل مع الأنظمة القديمة، ضمان الأمان" }
    ]
  },
  {
    name: "مدرس خصوصي (Tutor)",
    description: "شرح مفاهيم معقدة بأسلوب مبسط.",
    category: "Education",
    tags: ["Learning", "Explain", "Tutor"],
    sections: {
      system: "أنت مدرس صبور وخبير في تبسيط العلوم.",
      developer: "استخدم التشبيهات (Analogies) لشرح الأفكار. اشرح وكأنك تخاطب طالباً في الثانوية.",
      user: "اشرح لي مفهوم: {{concept}}.",
      context: "المجال: {{field}}"
    },
    defaultVariables: [
      { id: "v1", name: "concept", value: "Quantum Entanglement (التشابك الكمي)" },
      { id: "v2", name: "field", value: "الفيزياء" }
    ]
  },
  {
    name: "محسن النصوص (Rewriter)",
    description: "إعادة صياغة النص ليكون أكثر وضوحاً أو بأسلوب مختلف.",
    category: "Writing",
    tags: ["Rewrite", "Editing"],
    sections: {
      system: "أنت محرر نصوص لغوي.",
      developer: "حافظ على المعنى الأصلي ولكن حسن المفردات والتدفق.",
      user: "أعد صياغة النص التالي بأسلوب {{style}}:\n\n{{text}}",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "style", value: "أكثر رسمية" },
      { id: "v2", name: "text", value: "الشغل ماشي تمام بس فيه شوية مشاكل صغيرة هنحلها." }
    ]
  },
  {
    name: "مولد اختبارات (Quiz)",
    description: "إنشاء أسئلة اختيار من متعدد حول موضوع معين.",
    category: "Education",
    tags: ["Quiz", "Exam", "MCQ"],
    sections: {
      system: "أنت واضع اختبارات أكاديمية.",
      developer: "أنشئ أسئلة بصيغة JSON: {question, options[], correct_answer}.",
      user: "أنشئ {{count}} أسئلة اختيار من متعدد عن موضوع: {{topic}}.\nالصعوبة: {{difficulty}}.",
      context: ""
    },
    defaultVariables: [
      { id: "v1", name: "count", value: "3" },
      { id: "v2", name: "topic", value: "تاريخ الدولة الأموية" },
      { id: "v3", name: "difficulty", value: "متوسط" }
    ]
  }
];

const SEED_TECHNIQUES = [
  {
    title: "Chain of Thought (CoT)",
    description: "اطلب من النموذج التفكير خطوة بخطوة قبل الإجابة لزيادة الدقة في المهام المنطقية.",
    goodExample: "السؤال: ...\nالإجابة: لنفكر خطوة بخطوة. أولاً، نحسب... ثم نقارن... وبالتالي النتيجة هي...",
    badExample: "أعطني الجواب فوراً.",
    commonMistakes: ["نسيان عبارة 'فكر خطوة بخطوة'", "استخدامه في مهام إبداعية بسيطة لا تحتاج منطق"],
    snippet: "فكر خطوة بخطوة قبل تقديم الإجابة النهائية."
  },
  {
    title: "Few-Shot Prompting",
    description: "توفير أمثلة (Input -> Output) لتعليم النموذج النمط المتوقع.",
    goodExample: "مهمة: تصنيف المشاعر\nنص: أحب هذا المنتج -> إيجابي\nنص: سيء جداً -> سلبي\nنص: لا بأس به -> محايد\nنص: الشحن تأخر ->",
    badExample: "صنف مشاعر النصوص التالية بدون أمثلة.",
    commonMistakes: ["أمثلة غير متنوعة", "وجود أخطاء في الأمثلة المقدمة"],
    snippet: "إليك بعض الأمثلة لتتبع نمطها:\nالمثال 1: [مدخل] -> [مخرج]\nالمثال 2: [مدخل] -> [مخرج]"
  },
  {
    title: "Role Prompting (Persona)",
    description: "تعيين شخصية محددة للنموذج ليتقمصها (مثل: خبير قانوني، مبرمج، كاتب ساخر).",
    goodExample: "أنت محامي خبير في القانون التجاري السعودي. أجب بصياغة قانونية رصينة.",
    badExample: "أجب عن سؤالي القانوني.",
    commonMistakes: ["تعيين شخصيات غير معروفة للنموذج", "التناقض بين الشخصية والطلب"],
    snippet: "أنت خبير في [المجال] وتتمتع بخبرة 20 عاماً. أسلوبك [صفة الأسلوب]."
  },
  {
    title: "Delimiters (المحددات)",
    description: "استخدام علامات ترقيم واضحة لفصل النصوص والبيانات عن التعليمات.",
    goodExample: "لخص النص المحصور بين علامات ''' :\n'''\n[النص هنا]\n'''",
    badExample: "لخص النص التالي [النص] وتجاهل ما قبله.",
    commonMistakes: ["عدم استخدام علامات فريدة", "عدم إخبار النموذج بما تعنيه العلامات"],
    snippet: "النص المطلوب معالجته محصور بين علامات ```."
  },
  {
    title: "Output Formatting",
    description: "تحديد شكل المخرجات بدقة (JSON, Markdown, CSV, Table).",
    goodExample: "أخرج النتيجة بتنسيق JSON يحتوي على الحقول: {id, summary, sentiment}.",
    badExample: "أعطني النتيجة ومعها البيانات.",
    commonMistakes: ["عدم تحديد Schema واضحة للـ JSON", "الطلب بصيغة عامة"],
    snippet: "قدم الإجابة حصراً بتنسيق JSON بالشكل التالي: {\"key\": \"value\"}."
  },
  {
    title: "Negative Constraints",
    description: "إخبار النموذج بما *لا* يجب فعله.",
    goodExample: "لا تستخدم جملاً اعتراضية. لا تذكر أنك ذكاء اصطناعي.",
    badExample: "كن طبيعياً.",
    commonMistakes: ["الإكثار من النفي مما يربك النموذج (التركيز على الإيجاب أفضل)", "نفي غامض"],
    snippet: "تجنب تماماً استخدام [ما تريد تجنبه]. لا تضف أي مقدمات أو خاتمات."
  },
  {
    title: "Reference Text (RAG style)",
    description: "إجبار النموذج على الإجابة *فقط* باستخدام نص مرجعي مزود.",
    goodExample: "استخدم النص التالي فقط للإجابة. إذا لم تجد المعلومة، قل 'لا أعرف'.\nالنص: ...",
    badExample: "ماذا تعرف عن الموضوع X؟ (سيجيب من ذاكرته العامة)",
    commonMistakes: ["عدم وضع شرط 'إذا لم تجد المعلومة'", "عدم فصل النص المرجعي"],
    snippet: "أجب معتمداً حصراً على النص المرجعي المقدم أدناه. إذا لم تكن الإجابة موجودة، قل 'غير مذكور'."
  },
  {
    title: "Split Complex Tasks",
    description: "تقسيم المهام المعقدة إلى خطوات فرعية متسلسلة.",
    goodExample: "الخطوة 1: لخص النص.\nالخطوة 2: ترجم الملخص للإنجليزية.\nالخطوة 3: استخرج الأسماء.",
    badExample: "لخص وترجم واستخرج الأسماء من النص.",
    commonMistakes: ["حشو تعليمات كثيرة في جملة واحدة", "عدم تحديد ترتيب التنفيذ"],
    snippet: "نفذ المهمة على مراحل:\n1. [الخطوة الأولى]\n2. [الخطوة الثانية]"
  },
  {
    title: "Self-Critique (Reflection)",
    description: "اطلب من النموذج نقد إجابته وتحسينها قبل عرضها.",
    goodExample: "اكتب مسودة للإجابة، ثم انتقدها بحثاً عن تحيزات، ثم اكتب النسخة النهائية.",
    badExample: "اكتب إجابة مثالية.",
    commonMistakes: ["عدم طلب النسخة النهائية فقط (قد يعرض المسودة والنقد)", "زيادة التكلفة (Tokens)"],
    snippet: "راجع إجابتك للتأكد من [معيار الجودة] وصحح أي أخطاء قبل العرض النهائي."
  },
  {
    title: "Give Time to Think",
    description: "إتاحة مساحة للنموذج 'للتفكير' (مثل CoT) للحصول على نتائج أدق.",
    goodExample: "حدد أولاً الحجج المؤيدة والمعارضة، ثم قرر موقفك.",
    badExample: "ما هو رأيك مباشرة؟",
    commonMistakes: ["الاستعجال في طلب النتيجة النهائية"],
    snippet: "خذ وقتك لتحليل جميع الجوانب قبل تكوين استنتاج."
  },
  {
    title: "Meta Prompting",
    description: "الطلب من النموذج أن يقوم هو بكتابة المطالبة (Prompt) لتحسينها.",
    goodExample: "أنا أريد [هدف]. اكتب لي أفضل Prompt لأرسله لـ ChatGPT لتحقيق هذا الهدف.",
    badExample: "ساعدني في كتابة سؤال.",
    commonMistakes: ["عدم تحديد الهدف بدقة"],
    snippet: "تصرف كخبير هندسة مطالبات. اكتب لي مطالبة محسنة لتحقيق الهدف التالي: [الهدف]"
  },
  {
    title: "Ask for Clarification",
    description: "السماح للنموذج بطرح أسئلة عليك إذا كانت المعلومات ناقصة.",
    goodExample: "إذا لم تكن المعلومات كافية، اسألني قبل أن تجيب.",
    badExample: "خمن المعلومات الناقصة.",
    commonMistakes: ["النموذج قد يسأل كثيراً إذا لم تضع حداً"],
    snippet: "قبل الإجابة، اطرح علي أي أسئلة توضيحية ضرورية لفهم المهمة بدقة."
  },
  {
    title: "System Message Priority",
    description: "وضع التعليمات الجوهرية (الشخصية، القيود) في System Message لضمان عدم نسيانها.",
    goodExample: "System: أنت مترجم فوري دقيق لا تضف أي شرح.\nUser: ترجم 'Hello'",
    badExample: "User: ترجم 'Hello' ولا تضف شرحاً (قد ينساها مع طول المحادثة)",
    commonMistakes: ["تكرار تعليمات النظام في رسالة المستخدم بلا داع"],
    snippet: "(يوضع في قسم System): مهمتك الأساسية هي [المهمة] وعليك الالتزام بالقيد التالي: [القيد]."
  },
  {
    title: "Emotional Prompting",
    description: "إضافة عبارات عاطفية (مثل 'هذا مهم جداً لمسيرتي') لتحفيز النموذج.",
    goodExample: "هذه المهمة حيوية جداً لنجاح المشروع. أرجوك ابذل قصارى جهدك.",
    badExample: "افعلها.",
    commonMistakes: ["المبالغة الشديدة التي قد تبدو سخيفة"],
    snippet: "هذا أمر بالغ الأهمية لتطوري المهني، لذا يرجى تقديم إجابة دقيقة وشاملة."
  },
  {
    title: "Tagging / Labeling",
    description: "استخدام وسوم XML-like لتحديد أجزاء النص بوضوح.",
    goodExample: "النص: <text>...</text>\nالتعليمات: <instructions>...</instructions>",
    badExample: "النص هو ... والتعليمات هي ...",
    commonMistakes: ["نسيان إغلاق الوسوم"],
    snippet: "سأزودك بالمدخلات داخل وسم <input>. المخرجات يجب أن تكون داخل وسم <output>."
  }
];

export async function seedDatabase() {
  console.log("🌱 Starting database seed...");
  console.log("DATABASE_URL:", process.env.DATABASE_URL ? "Found" : "NOT FOUND");

  try {
    // Seed Templates
    console.log("📚 Seeding templates...");
    for (const template of SEED_TEMPLATES) {
      console.log("Inserting:", template.name);
      await db.insert(templates).values(template);
    }
    console.log(`✅ Seeded ${SEED_TEMPLATES.length} templates`);

    // Seed Techniques
    console.log("🎯 Seeding techniques...");
    for (const technique of SEED_TECHNIQUES) {
      console.log("Inserting:", technique.title);
      await db.insert(techniques).values(technique);
    }
    console.log(`✅ Seeded ${SEED_TECHNIQUES.length} techniques`);

    console.log("🎉 Database seeding completed successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run seed immediately
seedDatabase()
  .then(() => {
    console.log("✨ Exiting...");
    process.exit(0);
  })
  .catch((err) => {
    console.error("Fatal error:", err);
    process.exit(1);
  });
